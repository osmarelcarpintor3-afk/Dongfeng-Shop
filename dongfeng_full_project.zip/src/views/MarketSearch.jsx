import React, {useState} from 'react'

const MARKET_URLS = {
  taobao: q => `https://s.taobao.com/search?q=${encodeURIComponent(q)}`,
  amazon: q => `https://www.amazon.ca/s?k=${encodeURIComponent(q)}`,
  aliexpress: q => `https://www.aliexpress.com/wholesale?SearchText=${encodeURIComponent(q)}`,
  alibaba: q => `https://www.alibaba.com/trade/search?SearchText=${encodeURIComponent(q)}`,
  shein: q => `https://www.shein.com/search?keyword=${encodeURIComponent(q)}`
}

export default function MarketSearch(){
  const [q,setQ] = useState('')
  const [market, setMarket] = useState('taobao')
  return (
    <div>
      <h2>Buscar en tiendas externas</h2>
      <div className="card">
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar producto..." />
        <select value={market} onChange={e=>setMarket(e.target.value)}>
          <option value="taobao">Taobao (recomendado)</option>
          <option value="amazon">Amazon.ca</option>
          <option value="aliexpress">AliExpress</option>
          <option value="alibaba">Alibaba</option>
          <option value="shein">SHEIN</option>
        </select>
        <button onClick={()=> {
          const url = MARKET_URLS[market](q)
          window.open(url, '_blank')
        }}>Buscar</button>
      </div>
      <p>Puedes copiar el enlace del producto encontrado y usar "Agregar enlace al carrito" en la versión completa.</p>
    </div>
  )
}
