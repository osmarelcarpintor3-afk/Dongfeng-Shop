import React from 'react'
export default function Home(){
  return (
    <div>
      <h1>Glory shop Osmarel</h1>
      <p>Encargos de piezas y accesorios para Dongfeng Glory 330s y otros. Regístrate o inicia sesión para hacer encargos.</p>
      <img src="/assets/auth_screenshot.png" alt="auth screenshot" style={{maxWidth:400}}/>
    </div>
  )
}
