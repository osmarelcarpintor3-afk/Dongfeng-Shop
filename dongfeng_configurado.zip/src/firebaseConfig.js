const firebaseConfig = {
  apiKey: "AIzaSyAWcODwF_A7OtxStblzKm4umzUp4R1Iezc",
  authDomain: "dongfeng-shop.firebaseapp.com",
  projectId: "dongfeng-shop",
  storageBucket: "dongfeng-shop.firebasestorage.app",
  messagingSenderId: "1056045914968",
  appId: "1:1056045914968:web:246315eda4940d23dfe32d",
  measurementId: "G-G9YP4CZ0HJ"
};
export default firebaseConfig;
