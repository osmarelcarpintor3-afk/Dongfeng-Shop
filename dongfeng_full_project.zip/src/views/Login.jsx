import React, {useState} from 'react'
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth'
import { initializeApp } from 'firebase/app'
import firebaseConfig from '../firebaseConfig'

initializeApp(firebaseConfig)
const auth = getAuth()

export default function Login(){
  const [email,setEmail]=useState(''), [pass,setPass]=useState('')
  async function register(){
    try{
      await createUserWithEmailAndPassword(auth, email, pass)
      alert('Registrado. Revisa tu email.')
    }catch(e){ alert(e.message) }
  }
  async function login(){
    try{
      await signInWithEmailAndPassword(auth, email, pass)
      alert('Sesión iniciada')
    }catch(e){ alert(e.message) }
  }
  return (
    <div>
      <h2>Iniciar sesión / Registrarse</h2>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="Contraseña" type="password" value={pass} onChange={e=>setPass(e.target.value)} />
      <div>
        <button onClick={login}>Iniciar sesión</button>
        <button onClick={register}>Registrarse</button>
      </div>
    </div>
  )
}
