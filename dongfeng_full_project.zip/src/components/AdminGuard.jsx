import React from 'react'
import { useEffect, useState } from 'react'
import { getAuth, onAuthStateChanged } from 'firebase/auth'
import { ADMIN_UID } from '../admin'

export default function AdminGuard({children}) {
  const [ok, setOk] = useState(null)
  useEffect(()=> {
    const auth = getAuth()
    const unsub = onAuthStateChanged(auth, user => {
      if(!user) setOk(false)
      else setOk(user.uid === ADMIN_UID)
    })
    return ()=>unsub()
  },[])
  if(ok === null) return <div>Cargando...</div>
  if(!ok) return <div>Acceso denegado. Solo administrador.</div>
  return children
}
