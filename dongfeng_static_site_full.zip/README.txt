Sitio estático listo para GitHub Pages.

Cómo publicar:
1. Descomprime este ZIP en tu móvil.
2. Entra a tu repo en GitHub -> Upload files
3. Sube TODO el contenido de esta carpeta (archivos y la carpeta assets).
4. Haz Commit.
5. Ve a Settings -> Pages -> Deploy from 'main' branch / root (o usar GitHub Actions).
6. Espera unos minutos y abre la URL de GitHub Pages.

Notas:
- Reemplaza admin phone number in cart.html (variable adminNumber) por tu número con código de país.
- Firebase: activa Authentication (Email/Password), Firestore (colección 'products'), Realtime DB (chat), Storage (opcional).
- admin UID ya configurado.
