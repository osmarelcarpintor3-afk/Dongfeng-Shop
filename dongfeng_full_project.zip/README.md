Proyecto completo listo.
Instrucciones:
1) Reemplaza / añade tu repo en GitHub con estos archivos.
2) En Firebase Console: activa Auth Email/Password, Firestore, Realtime DB, Storage.
3) Asegúrate de que src/firebaseConfig.js contiene tu config (ya integrado).
4) Asegúrate de que src/admin.js contiene tu ADMIN_UID (ya integrado).
5) Conecta GitHub repo con Firebase Hosting o usa GitHub Pages (si eliges, ajustar build).
