import React, {useState} from 'react'
export default function Catalog(){
  const [products] = useState([
    {sku:'DF-330-001', name:'Filtro de aceite', short:'Filtro para motor 1.5', type:'internal'},
    {sku:'DF-330-002', name:'Pastillas de freno delanteras', short:'Juego 4 piezas', type:'internal'}
  ])
  return (
    <div>
      <h2>Catálogo interno</h2>
      {products.map(p => (
        <div key={p.sku} className="card">
          <h3>{p.name}</h3>
          <p>{p.short}</p>
          <button onClick={()=> alert('Añadido al carrito (simulado)')}>Agregar al carrito</button>
        </div>
      ))}
      <p>Los precios están ocultos — pide presupuesto.</p>
    </div>
  )
}
