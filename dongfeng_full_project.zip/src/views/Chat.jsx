import React, {useEffect, useState} from 'react'
import { getDatabase, ref, push, onChildAdded } from 'firebase/database'
import { initializeApp } from 'firebase/app'
import firebaseConfig from '../firebaseConfig'

const app = initializeApp(firebaseConfig)

export default function Chat(){
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  useEffect(()=> {
    const db = getDatabase(app)
    const messagesRef = ref(db, 'chatMessages')
    onChildAdded(messagesRef, snap => {
      setMessages(m => [...m, snap.val()])
    })
  },[])
  function send(){
    const db = getDatabase(app)
    const messagesRef = ref(db, 'chatMessages')
    push(messagesRef, { displayName: 'Anon', message: text, createdAt: Date.now() })
    setText('')
  }
  return (
    <div>
      <h2>Chat en vivo (público)</h2>
      <div className="card" style={{maxHeight:300, overflow:'auto'}}>
        {messages.map((m,i)=> <div key={i}><strong>{m.displayName}:</strong> {m.message}</div>)}
      </div>
      <input value={text} onChange={e=>setText(e.target.value)} placeholder="Escribe..." />
      <button onClick={send}>Enviar</button>
    </div>
  )
}
