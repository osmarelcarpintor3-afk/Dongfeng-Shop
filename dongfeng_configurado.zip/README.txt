Proyecto configurado con firebaseConfig y ADMIN_UID.
Sube estos archivos a GitHub.