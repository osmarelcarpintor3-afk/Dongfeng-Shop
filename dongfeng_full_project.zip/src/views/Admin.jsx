import React from 'react'
export default function Admin(){
  return (
    <div>
      <h2>Panel Admin</h2>
      <p>Desde aquí podrás gestionar productos, usuarios y moderar el chat. Implementa las llamadas a Firestore en la versión completa.</p>
    </div>
  )
}
