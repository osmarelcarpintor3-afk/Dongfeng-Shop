import React from 'react'
import { createWhatsAppLink } from '../utils/whatsapp'

const adminNumber = '5493412345678' // REEMPLAZA por tu numero con codigo de pais sin signos
const mockUser = { displayName:'Cliente Demo', email:'demo@ejemplo.com', phone:'+5493412345678' }
const mockCart = [
  { type:'internal', sku:'DF-330-001', name:'Filtro de aceite' },
  { type:'external', title:'Bombillo H4 en Amazon', link:'https://www.amazon.ca/dp/EXAMPLE' }
]

export default function Cart(){
  function handleEncargo(){
    const link = createWhatsAppLink(adminNumber, mockUser, mockCart)
    window.open(link, '_blank')
  }
  return (
    <div>
      <h2>Carrito</h2>
      <div className="card">
        {mockCart.map((it, i)=> (
          <div key={i}>
            <p>{i+1}) {it.type === 'internal' ? `${it.name} (SKU: ${it.sku})` : `${it.title}`}</p>
          </div>
        ))}
        <p><strong>Precios ocultos — solicitar presupuesto</strong></p>
        <button onClick={handleEncargo}>Hacer encargo por WhatsApp</button>
      </div>
    </div>
  )
}
