export function createWhatsAppLink(adminNumber, user, cartItems) {
  const lines = [];
  lines.push('Encargo desde Sitio:');
  lines.push(`Cliente: ${user?.displayName || 'Sin nombre'} (email: ${user?.email || '—'}, tel: ${user?.phone || '—'})`);
  lines.push('');
  lines.push('Items:');
  cartItems.forEach((it, i) => {
    if(it.type === 'internal') {
      lines.push(`${i+1}) ${it.name} (SKU: ${it.sku})`);
    } else {
      lines.push(`${i+1}) ${it.title} — enlace: ${it.link}`);
    }
  });
  const text = encodeURIComponent(lines.join('\n'));
  return `https://wa.me/${adminNumber}?text=${text}`;
}
