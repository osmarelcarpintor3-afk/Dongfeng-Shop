import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import './styles.css'
import Home from './views/Home'
import Catalog from './views/Catalog'
import MarketSearch from './views/MarketSearch'
import Cart from './views/Cart'
import Chat from './views/Chat'
import Admin from './views/Admin'
import Login from './views/Login'
import AdminGuard from './components/AdminGuard'

function App(){
  return (
    <BrowserRouter>
      <header className="site-header">
        <div className="logo"><img src="/logo-combined.svg" alt="logo" height="48"/></div>
        <nav>
          <Link to="/">Inicio</Link>
          <Link to="/catalog">Catálogo</Link>
          <Link to="/market">Buscar tiendas</Link>
          <Link to="/videos">Videos</Link>
          <Link to="/chat">Chat</Link>
          <Link to="/cart">Carrito</Link>
        </nav>
        <div className="auth-links"><Link to="/login">Iniciar sesión</Link></div>
      </header>
      <main className="container">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/catalog" element={<Catalog/>}/>
          <Route path="/market" element={<MarketSearch/>}/>
          <Route path="/cart" element={<Cart/>}/>
          <Route path="/chat" element={<Chat/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path="/admin" element={<AdminGuard><Admin/></AdminGuard>}/>
        </Routes>
      </main>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
